package com.springJPA.JPAExample.service;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springJPA.JPAExample.entity.User;

public interface UserRepository extends JpaRepository<User,Long>{
	

}

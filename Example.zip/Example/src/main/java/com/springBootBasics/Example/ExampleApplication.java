package com.springBootBasics.Example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class ExampleApplication {

	public static void main(String[] args) {
		ApplicationContext applicationContext = 
				SpringApplication.run(ExampleApplication.class, args);
		
//		BookController Book = applicationContext.getBean(BookController.class);
//		
//		System.out.println(Book);
		
		for (String name : applicationContext.getBeanDefinitionNames()) {
			System.out.println(name);
		}	
	}

}

insert into course_details(id, username, created_Date, last_Updated_Date) values(10001, 'microservices', sysdate(), sysdate());
insert into course_details(id, username, created_Date, last_Updated_Date) values(10002, 'h2 demo', sysdate(), sysdate());
insert into course_details(id, username, created_Date, last_Updated_Date) values(10003, 'spring demo', sysdate(), sysdate());


package com.jpahibernate.JPAHIBERNATEEX.repository;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import com.jpahibernate.JPAHIBERNATEEX.JpahibernateexApplication;
import com.jpahibernate.JPAHIBERNATEEX.entity.Course;

@ExtendWith(SpringExtension.class)

@SpringBootTest(classes = JpahibernateexApplication.class)
class CourseRepositoryTest {
//	private Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	CourseRepository repository;

	@Test
	public void findById_basic() {
		Course course = repository.findById(10001L);
		assertEquals("jpa demo", course.getName());
	}
	
	@Test
	@DirtiesContext
	public void deleteById_basic() {
		repository.deleteById(10002L);
		assertNull(repository.findById(10002L));
		
	}	
	
	@Test
	@DirtiesContext
	public void save_basic() {
		Course course = repository.findById(10001L);
		assertEquals("jpa demo",course.getName());
		course.setName("JPA updated");
		repository.save(course);
		
		Course updatedcourse = repository.findById(10001L);
		assertEquals("JPA updated",updatedcourse.getName());
		
	}

	
	
}

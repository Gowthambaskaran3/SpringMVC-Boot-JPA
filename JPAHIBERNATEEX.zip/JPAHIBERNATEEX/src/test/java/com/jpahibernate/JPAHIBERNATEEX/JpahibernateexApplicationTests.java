package com.jpahibernate.JPAHIBERNATEEX;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpahibernateexApplicationTests {

	@Test
	void contextLoads() {
	}

}
